import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { getFullDataset } from './src/data/fullDataset';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Health Check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'GridPulse APM Backend', timestamp: new Date().toISOString() });
  });

  // API Route: Transformers Dataset
  app.get('/api/transformers', (req, res) => {
    const dataset = getFullDataset();
    res.json({ success: true, count: dataset.length, data: dataset });
  });

  // API Route: Gemini AI Copilot Diagnostics
  app.post('/api/ai-chat', async (req, res) => {
    try {
      const { prompt, selectedTransformerId, role } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.status(200).json({
          reply: "⚠️ GEMINI_API_KEY environment variable is not configured. (Using offline expert fallback model for grid diagnostics).\n\nBased on IEEE C57.104 standards, transformers with Dissolved Gas > 400 ppm and Winding Temp > 90°C should be flagged for urgent oil degassing and thermal hotspot testing."
        });
      }

      const dataset = getFullDataset();
      let contextSummary = `Total Transformer Fleet: ${dataset.length} units.\n`;
      const criticalCount = dataset.filter(t => t.Health_Status === 'Critical').length;
      const warningCount = dataset.filter(t => t.Health_Status === 'Warning').length;
      const healthyCount = dataset.filter(t => t.Health_Status === 'Healthy').length;

      contextSummary += `Status Breakdown: Healthy=${healthyCount}, Warning=${warningCount}, Critical=${criticalCount}.\n`;

      if (selectedTransformerId) {
        const target = dataset.find(t => t.Transformer_ID === selectedTransformerId);
        if (target) {
          contextSummary += `Focus Target Asset: ${JSON.stringify(target)}\n`;
        }
      }

      const systemInstruction = `You are GridPulse AI, an expert Senior Power System Diagnostic & High-Voltage Transformer Maintenance Engineer.
You analyze operational telemetry (Oil Temp, Winding Temp, Ambient Temp, Current, Voltage 11kV, Load %, Oil Level %, Moisture ppm, Dissolved Gas ppm, Vibration mm/s, Partial Discharge pC, Cooling Status, Health Status).
Provide precise, actionable, IEEE C57.104 & IEC 60599 compliant engineering insights. User role: ${role || 'ENGINEER'}.

Context of grid fleet:
${contextSummary}
`;

      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${systemInstruction}\nUser Question: ${prompt}`,
      });

      const replyText = response.text || "Diagnostic analysis completed without text output.";
      return res.json({ reply: replyText });

    } catch (error: any) {
      console.error('Error in /api/ai-chat:', error);
      return res.status(500).json({
        error: "Failed to generate AI diagnostic response.",
        details: error.message
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GridPulse APM server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
