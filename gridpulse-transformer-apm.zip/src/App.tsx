import React, { useState, useMemo } from 'react';
import { TransformerData, UserRole, WorkOrder, WorkOrderStatus, SimulationParams } from './types';
import { getFullDataset } from './data/fullDataset';
import { calculateHealthScore } from './utils/healthCalculations';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardOverview } from './components/DashboardOverview';
import { AssetInventoryTable } from './components/AssetInventoryTable';
import { TransformerDetailModal } from './components/TransformerDetailModal';
import { PredictiveDiagnostics } from './components/PredictiveDiagnostics';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { WorkOrdersManager } from './components/WorkOrdersManager';
import { GridSimulationSandbox } from './components/GridSimulationSandbox';
import { DatasetSchemaExplorer } from './components/DatasetSchemaExplorer';
import { AICopilotModal } from './components/AICopilotModal';
import { Bell, ShieldAlert, X, CheckCircle, Wrench } from 'lucide-react';

export default function App() {
  // Main Telemetry Dataset State
  const [baseTransformers, setBaseTransformers] = useState<TransformerData[]>(getFullDataset());
  const [simulationParams, setSimulationParams] = useState<SimulationParams | null>(null);

  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Role Based Access Control State
  const [currentRole, setCurrentRole] = useState<UserRole>('SUPER_ADMIN');

  // Modal & Selection States
  const [selectedTransformer, setSelectedTransformer] = useState<TransformerData | null>(null);
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [copilotTargetId, setCopilotTargetId] = useState<string | undefined>(undefined);
  const [showAlertsDrawer, setShowAlertsDrawer] = useState<boolean>(false);
  const [initialWoTransformer, setInitialWoTransformer] = useState<TransformerData | null>(null);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Pre-seeded Maintenance Work Orders
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([
    {
      id: 'WO-1001',
      transformerId: 'T0007',
      title: 'Urgent Oil Degassing & Cooling Fan Test',
      description: 'DGA level reached 439.9 ppm with Winding Temp at 93°C under 93% load. Perform emergency oil degassing.',
      priority: 'Emergency',
      status: 'In Progress',
      assignedTo: 'Eng. Sarah Jenkins (Field Ops)',
      createdAt: '2026-07-30',
      scheduledDate: '2026-08-01',
      category: 'Oil Filtration',
    },
    {
      id: 'WO-1002',
      transformerId: 'T0023',
      title: 'High Thermal Hotspot & Bushing Inspection',
      description: 'Winding hotspot reached 105.4°C. Conduct thermal camera inspection and load shedding.',
      priority: 'Emergency',
      status: 'Open',
      assignedTo: 'Eng. Alex Rivera (High Voltage)',
      createdAt: '2026-07-31',
      scheduledDate: '2026-08-02',
      category: 'Bushing Inspection',
    },
    {
      id: 'WO-1003',
      transformerId: 'T0085',
      title: 'Vibration & Partial Discharge Sensor Replacement',
      description: 'Vibration RMS at 4.79 mm/s with Partial Discharge at 93 pC. Recalibrate acoustic sensors.',
      priority: 'High',
      status: 'Scheduled',
      assignedTo: 'Tech. Marcus Vance',
      createdAt: '2026-07-31',
      scheduledDate: '2026-08-03',
      category: 'General Overhaul',
    },
  ]);

  // Compute Simulated Telemetry Data
  const transformers = useMemo(() => {
    if (!simulationParams) return baseTransformers;

    return baseTransformers.map(t => {
      const newAmbient = Math.min(50, t.Ambient_Temperature_C + simulationParams.ambientTempDelta);
      const newLoad = Math.min(120, t.Load_Percentage + simulationParams.loadPercentageDelta);
      const newWinding = Math.round((t.Winding_Temperature_C + simulationParams.ambientTempDelta + (simulationParams.loadPercentageDelta * 0.4)) * 10) / 10;
      const newOil = Math.round((t.Oil_Temperature_C + simulationParams.ambientTempDelta * 0.8) * 10) / 10;
      const newDGA = Math.round(t.Dissolved_Gas_ppm * simulationParams.acceleratedGasMultiplier * 10) / 10;

      let newHealth = t.Health_Status;
      if (newDGA > 400 || newWinding > 95) newHealth = 'Critical';
      else if (newDGA > 250 || newWinding > 85) newHealth = 'Warning';

      return {
        ...t,
        Ambient_Temperature_C: newAmbient,
        Load_Percentage: newLoad,
        Winding_Temperature_C: newWinding,
        Oil_Temperature_C: newOil,
        Dissolved_Gas_ppm: newDGA,
        Health_Status: newHealth,
      };
    });
  }, [baseTransformers, simulationParams]);

  // Critical Assets Count
  const criticalCount = transformers.filter(t => t.Health_Status === 'Critical').length;
  const openWorkOrdersCount = workOrders.filter(w => w.status !== 'Completed').length;

  // Work Order Handlers
  const handleAddWorkOrder = (wo: Omit<WorkOrder, 'id' | 'createdAt'>) => {
    const newWo: WorkOrder = {
      ...wo,
      id: `WO-${1000 + workOrders.length + 1}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setWorkOrders(prev => [newWo, ...prev]);
    showToast(`Work order ${newWo.id} created for asset ${newWo.transformerId}`);
  };

  const handleUpdateWorkOrderStatus = (id: string, status: WorkOrderStatus) => {
    setWorkOrders(prev => prev.map(w => w.id === id ? { ...w, status } : w));
    showToast(`Work order ${id} status updated to ${status}`);
  };

  const handleOpenWorkOrderForAsset = (t: TransformerData) => {
    setInitialWoTransformer(t);
    setActiveTab('workorders');
  };

  // CSV Import Handler
  const handleImportNewDataset = (imported: Partial<TransformerData>[]) => {
    const fullImported: TransformerData[] = imported.map((item, idx) => ({
      Transformer_ID: item.Transformer_ID || `T${(500 + idx + 1).toString().padStart(4, '0')}`,
      Age_Years: item.Age_Years || 5,
      Oil_Temperature_C: item.Oil_Temperature_C || 70,
      Winding_Temperature_C: item.Winding_Temperature_C || 80,
      Ambient_Temperature_C: item.Ambient_Temperature_C || 25,
      Voltage_kV: 11.0,
      Current_A: item.Current_A || 250,
      Load_Percentage: item.Load_Percentage || 60,
      Oil_Level_Percentage: item.Oil_Level_Percentage || 95,
      Moisture_ppm: item.Moisture_ppm || 15,
      Dissolved_Gas_ppm: item.Dissolved_Gas_ppm || 200,
      Vibration_mm_s: item.Vibration_mm_s || 2.5,
      Partial_Discharge_pC: item.Partial_Discharge_pC || 30,
      Cooling_Status: item.Cooling_Status || 'Normal',
      Health_Status: item.Health_Status || 'Healthy',
    }));

    setBaseTransformers(prev => [...fullImported, ...prev]);
    showToast(`Imported ${imported.length} new transformer records into fleet database!`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-3 right-4 z-50 bg-slate-900 border border-indigo-500/50 text-indigo-200 px-3.5 py-2 rounded-lg shadow-2xl flex items-center gap-2 text-[12px] animate-bounce">
          <CheckCircle className="h-4 w-4 text-indigo-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <Header
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        activeTab={activeTab}
        onOpenCopilot={() => { setCopilotTargetId(undefined); setIsCopilotOpen(true); }}
        criticalAlertCount={criticalCount}
        onOpenAlerts={() => setShowAlertsDrawer(true)}
      />

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          criticalCount={criticalCount}
          openWorkOrdersCount={openWorkOrdersCount}
        />

        {/* Content View Area */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-4 lg:p-5 max-w-[1600px] mx-auto w-full">
          
          {/* Active Simulation Indicator Banner */}
          {simulationParams && (
            <div className="mb-4 p-2.5 bg-indigo-950/40 border border-indigo-500/40 rounded-lg flex justify-between items-center text-[12px] text-indigo-200 shadow-sm">
              <div className="flex items-center space-x-2">
                <span className="h-2 w-2 rounded-full bg-indigo-400 animate-ping"></span>
                <span>
                  <strong>Active Grid Stress Test Simulation:</strong> Heatwave (+{simulationParams.ambientTempDelta}°C) | Load Surge (+{simulationParams.loadPercentageDelta}%) | Fan Failure ({simulationParams.coolingSystemFailureRate}%)
                </span>
              </div>
              <button
                onClick={() => setSimulationParams(null)}
                className="text-indigo-300 hover:text-white underline font-semibold text-[11px]"
              >
                Reset Base Values
              </button>
            </div>
          )}

          {/* Tab Views */}
          {activeTab === 'dashboard' && (
            <DashboardOverview
              transformers={transformers}
              onSelectTransformer={(t) => setSelectedTransformer(t)}
              onCreateWorkOrder={handleOpenWorkOrderForAsset}
              onOpenCopilot={(tId) => { setCopilotTargetId(tId); setIsCopilotOpen(true); }}
              currentRole={currentRole}
            />
          )}

          {activeTab === 'inventory' && (
            <AssetInventoryTable
              transformers={transformers}
              onSelectTransformer={(t) => setSelectedTransformer(t)}
              onCreateWorkOrder={handleOpenWorkOrderForAsset}
              onImportNewDataset={handleImportNewDataset}
              onOpenCopilot={(tId) => { setCopilotTargetId(tId); setIsCopilotOpen(true); }}
            />
          )}

          {activeTab === 'diagnostics' && (
            <PredictiveDiagnostics
              transformers={transformers}
              onSelectTransformer={(t) => setSelectedTransformer(t)}
              onOpenCopilot={(tId) => { setCopilotTargetId(tId); setIsCopilotOpen(true); }}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsCharts transformers={transformers} />
          )}

          {activeTab === 'workorders' && (
            <WorkOrdersManager
              workOrders={workOrders}
              transformers={transformers}
              onAddWorkOrder={handleAddWorkOrder}
              onUpdateWorkOrderStatus={handleUpdateWorkOrderStatus}
              currentRole={currentRole}
              initialTransformerForOrder={initialWoTransformer}
              onClearInitialTransformer={() => setInitialWoTransformer(null)}
            />
          )}

          {activeTab === 'simulation' && (
            <GridSimulationSandbox
              transformers={transformers}
              onApplySimulation={(params) => {
                setSimulationParams(params);
                showToast('Monte-Carlo grid simulation active!');
              }}
              onResetSimulation={() => {
                setSimulationParams(null);
                showToast('Reset telemetry to live base values.');
              }}
              isSimulated={!!simulationParams}
            />
          )}

          {activeTab === 'schema' && (
            <DatasetSchemaExplorer />
          )}

        </main>
      </div>

      {/* Detail Inspection Modal */}
      <TransformerDetailModal
        transformer={selectedTransformer}
        onClose={() => setSelectedTransformer(null)}
        onCreateWorkOrder={handleOpenWorkOrderForAsset}
        onOpenCopilot={(tId) => {
          setSelectedTransformer(null);
          setCopilotTargetId(tId);
          setIsCopilotOpen(true);
        }}
        currentRole={currentRole}
      />

      {/* AI Copilot Modal */}
      <AICopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        selectedTransformerId={copilotTargetId}
        transformers={transformers}
        currentRole={currentRole}
      />

      {/* Critical Alerts Drawer */}
      {showAlertsDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex justify-end">
          <div className="bg-slate-900 border-l border-slate-800 w-full max-w-md h-full p-6 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5 text-rose-400" />
                  Critical Substation Alerts ({criticalCount})
                </h3>
                <button onClick={() => setShowAlertsDrawer(false)} className="text-slate-400 hover:text-slate-100">
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-3 max-h-[70vh] overflow-y-auto">
                {transformers.filter(t => t.Health_Status === 'Critical').slice(0, 15).map(t => (
                  <div key={t.Transformer_ID} className="p-3 bg-slate-950 border border-rose-900/50 rounded-xl space-y-1 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-mono font-bold text-rose-300">{t.Transformer_ID}</span>
                      <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-800 px-2 py-0.5 rounded font-bold">
                        CRITICAL DGA
                      </span>
                    </div>
                    <p className="text-slate-400">
                      Dissolved Gas: <strong className="text-rose-400">{t.Dissolved_Gas_ppm} ppm</strong> | Winding Temp: <strong className="text-amber-400">{t.Winding_Temperature_C}°C</strong>
                    </p>
                    <div className="pt-2 flex justify-end space-x-2">
                      <button
                        onClick={() => {
                          setShowAlertsDrawer(false);
                          setSelectedTransformer(t);
                        }}
                        className="text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded"
                      >
                        Inspect
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => setShowAlertsDrawer(false)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl"
            >
              Close Alerts Panel
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
