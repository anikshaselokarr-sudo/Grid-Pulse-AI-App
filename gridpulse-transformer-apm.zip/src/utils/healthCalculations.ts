import { TransformerData, HealthStatus } from '../types';

/**
 * Calculates IEEE C57.104 & IEC 60599 based Health Index Score (0 - 100)
 */
export function calculateHealthScore(t: TransformerData): number {
  // Gas Factor (Max 35 points penalty)
  // Normal DGA < 200 ppm, Warning 200-400 ppm, Critical > 400 ppm
  let gasPenalty = 0;
  if (t.Dissolved_Gas_ppm > 450) gasPenalty = 35;
  else if (t.Dissolved_Gas_ppm > 300) gasPenalty = 25;
  else if (t.Dissolved_Gas_ppm > 200) gasPenalty = 15;
  else if (t.Dissolved_Gas_ppm > 150) gasPenalty = 5;

  // Thermal Penalty (Max 25 points penalty)
  let thermalPenalty = 0;
  if (t.Winding_Temperature_C > 98) thermalPenalty = 25;
  else if (t.Winding_Temperature_C > 90) thermalPenalty = 18;
  else if (t.Winding_Temperature_C > 82) thermalPenalty = 10;
  else if (t.Winding_Temperature_C > 75) thermalPenalty = 5;

  // Moisture Penalty (Max 15 points)
  let moisturePenalty = 0;
  if (t.Moisture_ppm > 30) moisturePenalty = 15;
  else if (t.Moisture_ppm > 22) moisturePenalty = 10;
  else if (t.Moisture_ppm > 15) moisturePenalty = 5;

  // Partial Discharge & Vibration Penalty (Max 15 points)
  let mechanicalPenalty = 0;
  if (t.Vibration_mm_s > 4.2 || t.Partial_Discharge_pC > 75) mechanicalPenalty = 15;
  else if (t.Vibration_mm_s > 3.2 || t.Partial_Discharge_pC > 50) mechanicalPenalty = 10;
  else if (t.Vibration_mm_s > 2.5 || t.Partial_Discharge_pC > 30) mechanicalPenalty = 5;

  // Age Aging Penalty (Max 10 points)
  let agePenalty = Math.min(10, Math.floor(t.Age_Years * 0.35));

  const totalScore = Math.max(0, 100 - (gasPenalty + thermalPenalty + moisturePenalty + mechanicalPenalty + agePenalty));
  return Math.round(totalScore * 10) / 10;
}

/**
 * Estimates Remaining Useful Life (RUL) in years based on insulation aging acceleration factor (IEEE C57.91)
 */
export function estimateRULYears(t: TransformerData): number {
  const designLife = 35; // Standard design life in years
  const remainingStandardYears = Math.max(1, designLife - t.Age_Years);

  // Accelerated Aging Factor (FAA) driven by winding temperature
  // Normal reference winding temp is 110C hot spot, baseline 98C
  const hotspotTemp = t.Winding_Temperature_C + 8; // Hotspot delta approximation
  const faa = Math.exp((15000 / (110 + 273)) - (15000 / (hotspotTemp + 273)));

  // Degradation multiplier based on moisture & DGA
  const moistureDegradation = 1 + (t.Moisture_ppm / 40);
  const gasDegradation = 1 + (t.Dissolved_Gas_ppm / 500);

  const totalDegradationRate = Math.max(0.5, faa * moistureDegradation * gasDegradation);
  const RUL = remainingStandardYears / totalDegradationRate;

  return Math.max(0.5, Math.round(RUL * 10) / 10);
}

/**
 * Calculates Thermal Stress Index (0 - 100)
 */
export function calculateThermalStress(t: TransformerData): number {
  const windingDelta = t.Winding_Temperature_C - t.Ambient_Temperature_C;
  const oilDelta = t.Oil_Temperature_C - t.Ambient_Temperature_C;

  const score = Math.min(100, (windingDelta / 70) * 60 + (oilDelta / 60) * 40);
  return Math.round(score);
}

/**
 * Returns Duval Triangle Gas Composition Simulation (ppm broken down into key gases)
 */
export function estimateDGAGasBreakdown(dissolvedGasPpm: number) {
  // Proportional synthesis of key gases for DGA Duval Triangle
  const methane = Math.round(dissolvedGasPpm * 0.38); // CH4
  const ethane = Math.round(dissolvedGasPpm * 0.22); // C2H6
  const ethylene = Math.round(dissolvedGasPpm * 0.25); // C2H4
  const acetylene = Math.round(dissolvedGasPpm * 0.08); // C2H2
  const hydrogen = Math.round(dissolvedGasPpm * 0.07); // H2

  return { methane, ethane, ethylene, acetylene, hydrogen, total: dissolvedGasPpm };
}

/**
 * Returns overall risk category label
 */
export function getRiskCategory(score: number): 'Low' | 'Medium' | 'High' | 'Severe' {
  if (score >= 80) return 'Low';
  if (score >= 60) return 'Medium';
  if (score >= 40) return 'High';
  return 'Severe';
}
