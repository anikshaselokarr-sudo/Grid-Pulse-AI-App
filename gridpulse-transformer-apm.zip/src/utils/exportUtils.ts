import { TransformerData } from '../types';

export function exportToCSV(data: TransformerData[], filename = 'transformers_telemetry_export.csv') {
  if (!data || data.length === 0) return;

  const headers = [
    'Transformer_ID',
    'Age_Years',
    'Oil_Temperature_C',
    'Winding_Temperature_C',
    'Ambient_Temperature_C',
    'Voltage_kV',
    'Current_A',
    'Load_Percentage',
    'Oil_Level_Percentage',
    'Moisture_ppm',
    'Dissolved_Gas_ppm',
    'Vibration_mm_s',
    'Partial_Discharge_pC',
    'Cooling_Status',
    'Health_Status'
  ];

  const csvRows = [headers.join(',')];

  data.forEach(item => {
    const row = [
      item.Transformer_ID,
      item.Age_Years,
      item.Oil_Temperature_C,
      item.Winding_Temperature_C,
      item.Ambient_Temperature_C,
      item.Voltage_kV,
      item.Current_A,
      item.Load_Percentage,
      item.Oil_Level_Percentage,
      item.Moisture_ppm,
      item.Dissolved_Gas_ppm,
      item.Vibration_mm_s,
      item.Partial_Discharge_pC,
      `"${item.Cooling_Status}"`,
      `"${item.Health_Status}"`
    ];
    csvRows.push(row.join(','));
  });

  const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function parseCSVInput(csvText: string): Partial<TransformerData>[] {
  const lines = csvText.split(/\r\n|\n/).filter(line => line.trim().length > 0);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  const results: Partial<TransformerData>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    if (values.length < headers.length) continue;

    const rowObj: Record<string, any> = {};
    headers.forEach((header, idx) => {
      rowObj[header] = values[idx];
    });

    results.push({
      Transformer_ID: rowObj.Transformer_ID || `T${(500 + i).toString().padStart(4, '0')}`,
      Age_Years: parseFloat(rowObj.Age_Years) || 5,
      Oil_Temperature_C: parseFloat(rowObj.Oil_Temperature_C) || 70,
      Winding_Temperature_C: parseFloat(rowObj.Winding_Temperature_C) || 80,
      Ambient_Temperature_C: parseFloat(rowObj.Ambient_Temperature_C) || 25,
      Voltage_kV: parseFloat(rowObj.Voltage_kV) || 11.0,
      Current_A: parseFloat(rowObj.Current_A) || 250,
      Load_Percentage: parseFloat(rowObj.Load_Percentage) || 60,
      Oil_Level_Percentage: parseFloat(rowObj.Oil_Level_Percentage) || 95,
      Moisture_ppm: parseFloat(rowObj.Moisture_ppm) || 15,
      Dissolved_Gas_ppm: parseFloat(rowObj.Dissolved_Gas_ppm) || 200,
      Vibration_mm_s: parseFloat(rowObj.Vibration_mm_s) || 2.5,
      Partial_Discharge_pC: parseFloat(rowObj.Partial_Discharge_pC) || 30,
      Cooling_Status: rowObj.Cooling_Status || 'Normal',
      Health_Status: rowObj.Health_Status || 'Healthy'
    });
  }

  return results;
}
