export type HealthStatus = 'Healthy' | 'Warning' | 'Critical';
export type CoolingStatus = 'Normal' | 'Fan Running' | 'Oil Pump Running';

export interface TransformerData {
  Transformer_ID: string;
  Age_Years: number;
  Oil_Temperature_C: number;
  Winding_Temperature_C: number;
  Ambient_Temperature_C: number;
  Voltage_kV: number;
  Current_A: number;
  Load_Percentage: number;
  Oil_Level_Percentage: number;
  Moisture_ppm: number;
  Dissolved_Gas_ppm: number;
  Vibration_mm_s: number;
  Partial_Discharge_pC: number;
  Cooling_Status: CoolingStatus;
  Health_Status: HealthStatus;
  
  // Computed fields for APM
  healthScore?: number; // 0-100
  riskLevel?: 'Low' | 'Medium' | 'High' | 'Severe';
  estimatedRULYears?: number; // Remaining Useful Life
  thermalStressIndex?: number;
}

export type UserRole = 'SUPER_ADMIN' | 'GRID_OPS_MANAGER' | 'MAINTENANCE_ENGINEER' | 'FIELD_TECHNICIAN' | 'VIEWER';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
}

export type WorkOrderPriority = 'Low' | 'Medium' | 'High' | 'Emergency';
export type WorkOrderStatus = 'Open' | 'Scheduled' | 'In Progress' | 'Completed' | 'Cancelled';

export interface WorkOrder {
  id: string;
  transformerId: string;
  title: string;
  description: string;
  priority: WorkOrderPriority;
  status: WorkOrderStatus;
  assignedTo: string;
  createdAt: string;
  scheduledDate: string;
  category: 'Oil Filtration' | 'Fan Repair' | 'Pump Replacement' | 'Bushing Inspection' | 'DGA Sampling' | 'General Overhaul';
}

export interface SimulationParams {
  ambientTempDelta: number; // e.g. -10 to +20
  loadPercentageDelta: number; // e.g. -30 to +30
  coolingSystemFailureRate: number; // 0 to 100%
  acceleratedGasMultiplier: number; // 1.0 to 2.5
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  target: string;
  details: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
}
