import React from 'react';
import { TransformerData, UserRole } from '../types';
import { calculateHealthScore, estimateRULYears, calculateThermalStress, estimateDGAGasBreakdown } from '../utils/healthCalculations';
import { X, ShieldAlert, AlertTriangle, CheckCircle2, Flame, Thermometer, Activity, Gauge, Sparkles, Wrench, Clock, Zap } from 'lucide-react';

interface TransformerDetailModalProps {
  transformer: TransformerData | null;
  onClose: () => void;
  onCreateWorkOrder: (t: TransformerData) => void;
  onOpenCopilot: (tId: string) => void;
  currentRole: UserRole;
}

export const TransformerDetailModal: React.FC<TransformerDetailModalProps> = ({
  transformer,
  onClose,
  onCreateWorkOrder,
  onOpenCopilot,
  currentRole,
}) => {
  if (!transformer) return null;

  const healthScore = calculateHealthScore(transformer);
  const rulYears = estimateRULYears(transformer);
  const thermalStress = calculateThermalStress(transformer);
  const gasBreakdown = estimateDGAGasBreakdown(transformer.Dissolved_Gas_ppm);

  let statusBadgeColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-800';
  if (transformer.Health_Status === 'Warning') statusBadgeColor = 'bg-amber-500/20 text-amber-300 border-amber-800';
  if (transformer.Health_Status === 'Critical') statusBadgeColor = 'bg-rose-500/20 text-rose-300 border-rose-800';

  return (
    <div id="modal-transformer-detail" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl relative">
        
        {/* Header Bar */}
        <div className="bg-slate-950 p-5 border-b border-slate-800 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-cyan-500/10 rounded-xl border border-cyan-500/30 text-cyan-400">
              <Zap className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center space-x-3">
                <h2 className="text-xl font-bold font-mono text-slate-100">{transformer.Transformer_ID}</h2>
                <span className={`px-2.5 py-0.5 text-xs font-bold rounded-md border ${statusBadgeColor}`}>
                  {transformer.Health_Status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">11kV Substation Power Transformer Telemetry & Diagnostic Report</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Diagnostic Key Performance Indicators */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            {/* Health Score Gauge Box */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">IEEE Health Score</span>
              <div className="text-3xl font-bold font-mono text-cyan-400">{healthScore} / 100</div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                <div style={{ width: `${healthScore}%` }} className="h-full bg-cyan-400" />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Based on IEEE C57.104 standards</p>
            </div>

            {/* Remaining Useful Life (RUL) Box */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Estimated RUL</span>
              <div className="text-3xl font-bold font-mono text-emerald-400">{rulYears} <span className="text-xs font-normal text-slate-400">years</span></div>
              <p className="text-[11px] text-slate-500 mt-2">Arrhenius hot-spot thermal aging model</p>
            </div>

            {/* Thermal Stress Index Box */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Thermal Stress</span>
              <div className={`text-3xl font-bold font-mono ${thermalStress > 70 ? 'text-rose-400' : 'text-amber-400'}`}>
                {thermalStress}%
              </div>
              <p className="text-[11px] text-slate-500 mt-2">Winding & oil temperature delta</p>
            </div>

          </div>

          {/* Detailed Telemetry Parameters Grid */}
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Telemetry Parameters</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              
              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Age:</span>
                <span className="font-mono font-bold text-slate-200">{transformer.Age_Years} Years</span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Winding Temp:</span>
                <span className="font-mono font-bold text-amber-300">{transformer.Winding_Temperature_C} °C</span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Oil Temp:</span>
                <span className="font-mono font-bold text-slate-200">{transformer.Oil_Temperature_C} °C</span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Ambient Temp:</span>
                <span className="font-mono font-bold text-slate-200">{transformer.Ambient_Temperature_C} °C</span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Current / Load:</span>
                <span className="font-mono font-bold text-cyan-300">{transformer.Current_A} A ({transformer.Load_Percentage}%)</span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Dissolved Gas (DGA):</span>
                <span className={`font-mono font-bold ${transformer.Dissolved_Gas_ppm > 400 ? 'text-rose-400' : 'text-slate-200'}`}>
                  {transformer.Dissolved_Gas_ppm} ppm
                </span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Moisture:</span>
                <span className="font-mono font-bold text-slate-200">{transformer.Moisture_ppm} ppm</span>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block">Vibration / PD:</span>
                <span className="font-mono font-bold text-slate-200">{transformer.Vibration_mm_s} mm/s | {transformer.Partial_Discharge_pC} pC</span>
              </div>

            </div>
          </div>

          {/* DGA Dissolved Gas Breakdown (Duval Triangle Key Indicators) */}
          <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
              DGA Gas Ratio Breakdown (Dissolved Key Gases)
            </h4>
            
            <div className="space-y-2 text-xs">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Methane (CH4) - Overheating</span>
                  <span className="font-mono">{gasBreakdown.methane} ppm</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div style={{ width: `${Math.min(100, (gasBreakdown.methane / 200) * 100)}%` }} className="bg-amber-400 h-full" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Ethylene (C2H4) - High Temp Thermal Fault</span>
                  <span className="font-mono">{gasBreakdown.ethylene} ppm</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div style={{ width: `${Math.min(100, (gasBreakdown.ethylene / 150) * 100)}%` }} className="bg-rose-400 h-full" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Acetylene (C2H2) - Arcing Hazard</span>
                  <span className="font-mono">{gasBreakdown.acetylene} ppm</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div style={{ width: `${Math.min(100, (gasBreakdown.acetylene / 50) * 100)}%` }} className="bg-purple-400 h-full" />
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="bg-slate-950 p-4 border-t border-slate-800 flex justify-between items-center">
          <button
            onClick={() => onOpenCopilot(transformer.Transformer_ID)}
            className="px-4 py-2 bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors"
          >
            <Sparkles className="h-4 w-4 text-purple-400" />
            <span>AI Copilot Analysis</span>
          </button>

          <div className="flex items-center space-x-2">
            {currentRole !== 'VIEWER' && (
              <button
                onClick={() => {
                  onClose();
                  onCreateWorkOrder(transformer);
                }}
                className="px-4 py-2 bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/40 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors"
              >
                <Wrench className="h-4 w-4" />
                <span>Create Maintenance Work Order</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
