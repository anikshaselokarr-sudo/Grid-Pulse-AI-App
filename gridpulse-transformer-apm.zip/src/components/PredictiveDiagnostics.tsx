import React, { useState } from 'react';
import { TransformerData } from '../types';
import { calculateHealthScore, estimateRULYears, calculateThermalStress } from '../utils/healthCalculations';
import { Stethoscope, AlertTriangle, ShieldAlert, CheckCircle2, Search, Flame, Thermometer, Filter, Info, ChevronRight } from 'lucide-react';

interface PredictiveDiagnosticsProps {
  transformers: TransformerData[];
  onSelectTransformer: (t: TransformerData) => void;
  onOpenCopilot: (tId: string) => void;
}

export const PredictiveDiagnostics: React.FC<PredictiveDiagnosticsProps> = ({
  transformers,
  onSelectTransformer,
  onOpenCopilot,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'CRITICAL_DGA' | 'THERMAL_OVERLOAD' | 'MOISTURE_DEGRADATION' | 'HIGH_VIBRATION'>('ALL');
  const [searchId, setSearchId] = useState('');

  const filtered = transformers.filter(t => {
    if (searchId && !t.Transformer_ID.toLowerCase().includes(searchId.toLowerCase())) {
      return false;
    }
    if (selectedCategory === 'CRITICAL_DGA') return t.Dissolved_Gas_ppm > 400;
    if (selectedCategory === 'THERMAL_OVERLOAD') return t.Winding_Temperature_C > 90 || t.Load_Percentage >= 90;
    if (selectedCategory === 'MOISTURE_DEGRADATION') return t.Moisture_ppm > 25;
    if (selectedCategory === 'HIGH_VIBRATION') return t.Vibration_mm_s > 3.8 || t.Partial_Discharge_pC > 65;
    return true;
  });

  return (
    <div id="predictive-diagnostics-container" className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-2">
          <div className="p-2.5 bg-cyan-500/10 rounded-xl border border-cyan-500/30 text-cyan-400">
            <Stethoscope className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">DGA & IEEE C57.104 Predictive Health Engine</h2>
            <p className="text-xs text-slate-400">Automated failure prediction, thermal acceleration indexing, and dissolved gas ratio analysis</p>
          </div>
        </div>

        {/* Diagnostic Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-slate-800">
          <button
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedCategory === 'ALL' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
          >
            All Substation Units ({transformers.length})
          </button>
          
          <button
            onClick={() => setSelectedCategory('CRITICAL_DGA')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedCategory === 'CRITICAL_DGA' ? 'bg-rose-500 text-white font-bold' : 'bg-slate-800 text-rose-300 hover:bg-slate-700'}`}
          >
            DGA Critical Hazard (&gt;400 ppm)
          </button>

          <button
            onClick={() => setSelectedCategory('THERMAL_OVERLOAD')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedCategory === 'THERMAL_OVERLOAD' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-amber-300 hover:bg-slate-700'}`}
          >
            Thermal Stress Hotspot (&gt;90°C)
          </button>

          <button
            onClick={() => setSelectedCategory('MOISTURE_DEGRADATION')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedCategory === 'MOISTURE_DEGRADATION' ? 'bg-indigo-500 text-white font-bold' : 'bg-slate-800 text-indigo-300 hover:bg-slate-700'}`}
          >
            Moisture Insulation Degradation (&gt;25 ppm)
          </button>
        </div>
      </div>

      {/* Grid List of Asset Diagnostic Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.slice(0, 30).map(t => {
          const score = calculateHealthScore(t);
          const rul = estimateRULYears(t);
          const thermal = calculateThermalStress(t);

          return (
            <div key={t.Transformer_ID} className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all shadow-sm">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <span className="font-mono font-bold text-sm text-slate-100">{t.Transformer_ID}</span>
                  <p className="text-[11px] text-slate-400">Age: {t.Age_Years} yrs | Load: {t.Load_Percentage}%</p>
                </div>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded border ${
                  t.Health_Status === 'Critical' ? 'bg-rose-500/20 text-rose-300 border-rose-800' :
                  t.Health_Status === 'Warning' ? 'bg-amber-500/20 text-amber-300 border-amber-800' :
                  'bg-emerald-500/20 text-emerald-300 border-emerald-800'
                }`}>
                  {t.Health_Status} ({score})
                </span>
              </div>

              {/* Metrics breakdown */}
              <div className="space-y-2 text-xs text-slate-300 mb-4 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
                <div className="flex justify-between">
                  <span className="text-slate-400">Dissolved Gas:</span>
                  <span className={`font-mono font-bold ${t.Dissolved_Gas_ppm > 400 ? 'text-rose-400' : 'text-slate-200'}`}>
                    {t.Dissolved_Gas_ppm} ppm
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">Winding Hotspot:</span>
                  <span className="font-mono text-amber-300">{t.Winding_Temperature_C} °C</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">Est RUL Life:</span>
                  <span className="font-mono text-emerald-400 font-bold">{rul} Years</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <button
                  onClick={() => onSelectTransformer(t)}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
                >
                  Inspect Full DGA <ChevronRight className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => onOpenCopilot(t.Transformer_ID)}
                  className="text-xs bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 px-2.5 py-1 rounded border border-purple-500/30 transition-colors"
                >
                  AI Copilot
                </button>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
