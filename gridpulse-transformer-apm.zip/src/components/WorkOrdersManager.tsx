import React, { useState } from 'react';
import { WorkOrder, TransformerData, UserRole, WorkOrderPriority, WorkOrderStatus } from '../types';
import { Wrench, Plus, CheckCircle2, Clock, AlertTriangle, UserCheck, Calendar, Filter, X } from 'lucide-react';

interface WorkOrdersManagerProps {
  workOrders: WorkOrder[];
  transformers: TransformerData[];
  onAddWorkOrder: (wo: Omit<WorkOrder, 'id' | 'createdAt'>) => void;
  onUpdateWorkOrderStatus: (id: string, status: WorkOrderStatus) => void;
  currentRole: UserRole;
  initialTransformerForOrder?: TransformerData | null;
  onClearInitialTransformer?: () => void;
}

export const WorkOrdersManager: React.FC<WorkOrdersManagerProps> = ({
  workOrders,
  transformers,
  onAddWorkOrder,
  onUpdateWorkOrderStatus,
  currentRole,
  initialTransformerForOrder,
  onClearInitialTransformer,
}) => {
  const [showCreateModal, setShowCreateModal] = useState<boolean>(!!initialTransformerForOrder);
  const [statusFilter, setStatusFilter] = useState<WorkOrderStatus | 'ALL'>('ALL');

  // Form state
  const [selectedAssetId, setSelectedAssetId] = useState<string>(
    initialTransformerForOrder ? initialTransformerForOrder.Transformer_ID : (transformers[0]?.Transformer_ID || 'T0001')
  );
  const [title, setTitle] = useState<string>(
    initialTransformerForOrder ? `Urgent Maintenance for ${initialTransformerForOrder.Transformer_ID}` : 'Substation Maintenance Dispatch'
  );
  const [description, setDescription] = useState<string>(
    initialTransformerForOrder ? `Transformer DGA concentration at ${initialTransformerForOrder.Dissolved_Gas_ppm} ppm with Winding Temp at ${initialTransformerForOrder.Winding_Temperature_C}°C. Perform urgent oil degassing and thermal camera scan.` : ''
  );
  const [priority, setPriority] = useState<WorkOrderPriority>(
    initialTransformerForOrder?.Health_Status === 'Critical' ? 'Emergency' : 'High'
  );
  const [assignedTo, setAssignedTo] = useState<string>('Eng. Sarah Jenkins (Field Operations)');
  const [category, setCategory] = useState<WorkOrder['category']>('Oil Filtration');

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddWorkOrder({
      transformerId: selectedAssetId,
      title,
      description,
      priority,
      status: 'Open',
      assignedTo,
      scheduledDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
      category,
    });
    setShowCreateModal(false);
    if (onClearInitialTransformer) onClearInitialTransformer();
  };

  const filteredWorkOrders = workOrders.filter(wo => {
    if (statusFilter === 'ALL') return true;
    return wo.status === statusFilter;
  });

  return (
    <div id="work-orders-container" className="space-y-6">
      
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Wrench className="h-5 w-5 text-amber-400" />
            Maintenance Dispatch & Work Orders Center
          </h2>
          <p className="text-xs text-slate-400">Schedule oil filtration, bushing replacement, cooling fan repair, and field technician dispatch</p>
        </div>

        {currentRole !== 'VIEWER' && (
          <button
            id="btn-create-work-order"
            onClick={() => setShowCreateModal(true)}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-2 transition-colors shadow-sm"
          >
            <Plus className="h-4 w-4 stroke-[3]" />
            <span>Create Work Order</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2 text-xs">
        {(['ALL', 'Open', 'In Progress', 'Scheduled', 'Completed'] as const).map((st) => (
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              statusFilter === st ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {st} ({st === 'ALL' ? workOrders.length : workOrders.filter(w => w.status === st).length})
          </button>
        ))}
      </div>

      {/* Work Orders Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] font-semibold text-slate-400 uppercase bg-slate-950/80 border-b border-slate-800">
              <tr>
                <th className="py-3 px-3">WO ID</th>
                <th className="py-3 px-3">Asset Target</th>
                <th className="py-3 px-3">Title & Category</th>
                <th className="py-3 px-3">Priority</th>
                <th className="py-3 px-3">Assigned Crew</th>
                <th className="py-3 px-3">Scheduled</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Update Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredWorkOrders.map((wo) => {
                let priorityBadge = 'bg-slate-800 text-slate-300';
                if (wo.priority === 'Emergency') priorityBadge = 'bg-rose-500/20 text-rose-300 border-rose-800';
                if (wo.priority === 'High') priorityBadge = 'bg-amber-500/20 text-amber-300 border-amber-800';

                return (
                  <tr key={wo.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-200">{wo.id}</td>
                    <td className="py-2.5 px-3 font-mono text-cyan-400 font-bold">{wo.transformerId}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-slate-200">{wo.title}</div>
                      <div className="text-[10px] text-slate-400">{wo.category}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded border ${priorityBadge}`}>
                        {wo.priority}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{wo.assignedTo}</td>
                    <td className="py-2.5 px-3 text-slate-400 font-mono">{wo.scheduledDate}</td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                        wo.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-300' :
                        wo.status === 'In Progress' ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {wo.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right space-x-1">
                      {currentRole !== 'VIEWER' && wo.status !== 'Completed' && (
                        <select
                          value={wo.status}
                          onChange={(e) => onUpdateWorkOrderStatus(wo.id, e.target.value as WorkOrderStatus)}
                          className="bg-slate-950 border border-slate-800 text-slate-200 rounded px-2 py-1 text-[11px] cursor-pointer"
                        >
                          <option value="Open">Open</option>
                          <option value="Scheduled">Scheduled</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                        </select>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Work Order Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 relative shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Wrench className="h-5 w-5 text-amber-400" />
                Dispatch New Maintenance Work Order
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-slate-100">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Target Asset ID</label>
                <select
                  value={selectedAssetId}
                  onChange={(e) => setSelectedAssetId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                >
                  {transformers.map(t => (
                    <option key={t.Transformer_ID} value={t.Transformer_ID}>
                      {t.Transformer_ID} - {t.Health_Status} (DGA: {t.Dissolved_Gas_ppm} ppm)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Work Order Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  >
                    <option value="Oil Filtration">Oil Filtration</option>
                    <option value="Fan Repair">Fan Repair</option>
                    <option value="Pump Replacement">Pump Replacement</option>
                    <option value="Bushing Inspection">Bushing Inspection</option>
                    <option value="DGA Sampling">DGA Sampling</option>
                    <option value="General Overhaul">General Overhaul</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Emergency">Emergency</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Description & Scope</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 text-slate-950 font-bold rounded-lg"
                >
                  Dispatch Work Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
