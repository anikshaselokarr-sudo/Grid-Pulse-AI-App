import React from 'react';
import { TransformerData, UserRole } from '../types';
import { calculateHealthScore } from '../utils/healthCalculations';
import { ShieldAlert, AlertTriangle, CheckCircle2, Zap, Flame, Activity, Thermometer, ArrowUpRight, Wrench, Sparkles } from 'lucide-react';

interface DashboardOverviewProps {
  transformers: TransformerData[];
  onSelectTransformer: (t: TransformerData) => void;
  onCreateWorkOrder: (t: TransformerData) => void;
  onOpenCopilot: (tId?: string) => void;
  currentRole: UserRole;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  transformers,
  onSelectTransformer,
  onCreateWorkOrder,
  onOpenCopilot,
  currentRole,
}) => {
  const totalCount = transformers.length;
  const healthy = transformers.filter(t => t.Health_Status === 'Healthy');
  const warning = transformers.filter(t => t.Health_Status === 'Warning');
  const critical = transformers.filter(t => t.Health_Status === 'Critical');

  const healthyPercent = Math.round((healthy.length / totalCount) * 100);
  const warningPercent = Math.round((warning.length / totalCount) * 100);
  const criticalPercent = Math.round((critical.length / totalCount) * 100);

  const avgAge = Math.round((transformers.reduce((acc, t) => acc + t.Age_Years, 0) / totalCount) * 10) / 10;
  const avgLoad = Math.round((transformers.reduce((acc, t) => acc + t.Load_Percentage, 0) / totalCount) * 10) / 10;
  const avgDGA = Math.round((transformers.reduce((acc, t) => acc + t.Dissolved_Gas_ppm, 0) / totalCount));
  const overloadedCount = transformers.filter(t => t.Load_Percentage >= 90).length;

  const topCriticalAssets = [...critical]
    .sort((a, b) => b.Dissolved_Gas_ppm - a.Dissolved_Gas_ppm)
    .slice(0, 5);

  return (
    <div id="dashboard-overview-container" className="space-y-6">
      
      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Total Assets Card */}
        <div id="kpi-card-total-fleet" className="bg-slate-900 border border-slate-800 rounded-lg p-3 shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Substation Fleet</p>
              <h3 className="text-2xl font-bold text-white mt-1">{totalCount} <span className="text-xs font-normal text-slate-400">Units</span></h3>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                <span>Avg Fleet Age:</span> <strong className="text-slate-200">{avgAge} yrs</strong>
              </p>
            </div>
            <div className="p-2 bg-indigo-600/10 rounded-md border border-indigo-500/20 text-indigo-400">
              <Zap className="h-4 w-4" />
            </div>
          </div>
        </div>

        {/* Healthy Assets Card */}
        <div id="kpi-card-healthy" className="bg-slate-900 border border-slate-800 rounded-lg p-3 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">Healthy Assets</p>
              <h3 className="text-2xl font-bold text-emerald-300 mt-1">{healthy.length} <span className="text-xs font-normal text-emerald-400/80">({healthyPercent}%)</span></h3>
              <p className="text-[11px] text-slate-400 mt-1">Nominal parameters under IEEE limits</p>
            </div>
            <div className="p-2 bg-emerald-500/10 rounded-md border border-emerald-500/20 text-emerald-400">
              <CheckCircle2 className="h-4 w-4" />
            </div>
          </div>
        </div>

        {/* Warning Assets Card */}
        <div id="kpi-card-warning" className="bg-slate-900 border border-slate-800 rounded-lg p-3 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">Warning Level</p>
              <h3 className="text-2xl font-bold text-amber-300 mt-1">{warning.length} <span className="text-xs font-normal text-amber-400/80">({warningPercent}%)</span></h3>
              <p className="text-[11px] text-slate-400 mt-1">Elevated DGA / Thermal stress</p>
            </div>
            <div className="p-2 bg-amber-500/10 rounded-md border border-amber-500/20 text-amber-400">
              <AlertTriangle className="h-4 w-4" />
            </div>
          </div>
        </div>

        {/* Critical Assets Card */}
        <div id="kpi-card-critical" className="bg-slate-900 border border-rose-950 rounded-lg p-3 shadow-sm bg-gradient-to-br from-slate-900 to-rose-950/20">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider">Critical Risk</p>
              <h3 className="text-2xl font-bold text-rose-300 mt-1">{critical.length} <span className="text-xs font-normal text-rose-400/80">({criticalPercent}%)</span></h3>
              <p className="text-[11px] text-rose-300/80 mt-1 flex items-center gap-1">
                <ShieldAlert className="h-3 w-3 text-rose-400" /> Urgent dispatch required
              </p>
            </div>
            <div className="p-2 bg-rose-500/10 rounded-md border border-rose-500/30 text-rose-400 animate-pulse">
              <ShieldAlert className="h-4 w-4" />
            </div>
          </div>
        </div>

      </div>

      {/* Grid Status Progress & Operational Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Fleet Health Distribution Gauge & Progress */}
        <div id="fleet-health-gauge-card" className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-100 uppercase tracking-tight flex items-center gap-2">
              <Activity className="h-4 w-4 text-indigo-400" />
              Fleet Health Distribution
            </h3>
            <span className="text-[11px] font-mono text-indigo-400 font-semibold">500 Total Assets</span>
          </div>

          <div className="space-y-3">
            {/* Multi-segment Health Bar */}
            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden flex border border-slate-800 shadow-inner">
              <div style={{ width: `${healthyPercent}%` }} className="bg-emerald-500 h-full transition-all duration-500" title={`Healthy: ${healthy.length}`} />
              <div style={{ width: `${warningPercent}%` }} className="bg-amber-500 h-full transition-all duration-500" title={`Warning: ${warning.length}`} />
              <div style={{ width: `${criticalPercent}%` }} className="bg-rose-500 h-full transition-all duration-500" title={`Critical: ${critical.length}`} />
            </div>

            <div className="grid grid-cols-3 gap-2 text-center pt-1">
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="block text-[10px] uppercase font-bold text-slate-500">Healthy</span>
                <span className="text-sm font-bold text-emerald-400">{healthy.length}</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="block text-[10px] uppercase font-bold text-slate-500">Warning</span>
                <span className="text-sm font-bold text-amber-400">{warning.length}</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="block text-[10px] uppercase font-bold text-slate-500">Critical</span>
                <span className="text-sm font-bold text-rose-400">{critical.length}</span>
              </div>
            </div>

            {/* Substation Thermal & Load Telemetry */}
            <div className="pt-2 border-t border-slate-800/80 space-y-1.5 text-[11px] text-slate-300">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 flex items-center gap-1.5"><Thermometer className="h-3.5 w-3.5 text-amber-400" /> Avg Fleet DGA:</span>
                <span className="font-mono font-bold text-slate-200">{avgDGA} ppm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 flex items-center gap-1.5"><Flame className="h-3.5 w-3.5 text-rose-400" /> Overloaded Transformers (≥90%):</span>
                <span className="font-mono font-bold text-amber-400">{overloadedCount} units</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 flex items-center gap-1.5"><Zap className="h-3.5 w-3.5 text-indigo-400" /> Substation Avg Load:</span>
                <span className="font-mono font-bold text-indigo-300">{avgLoad}%</span>
              </div>
            </div>

          </div>
        </div>

        {/* Live Critical Incident Ticker / Top Risk Assets */}
        <div id="top-critical-assets-card" className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-100 uppercase tracking-tight flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-rose-400" />
                Immediate Action Needed – High Risk Telemetry
              </h3>
              <p className="text-[11px] text-slate-400">Transformers with extreme DGA levels or insulation breakdown</p>
            </div>
            <button
              onClick={() => onOpenCopilot()}
              className="text-[11px] bg-indigo-600/15 text-indigo-300 hover:bg-indigo-600/25 border border-indigo-500/30 px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors font-semibold"
            >
              <Sparkles className="h-3.5 w-3.5" />
              AI Diagnostics
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[12px] text-slate-300">
              <thead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider bg-slate-950 border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Asset ID</th>
                  <th className="py-2 px-3">Age</th>
                  <th className="py-2 px-3">Winding Temp</th>
                  <th className="py-2 px-3">DGA (ppm)</th>
                  <th className="py-2 px-3">Load %</th>
                  <th className="py-2 px-3">Cooling</th>
                  <th className="py-2 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {topCriticalAssets.map((t) => {
                  const score = calculateHealthScore(t);
                  return (
                    <tr key={t.Transformer_ID} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2 px-3 font-mono font-bold text-rose-300 flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse"></span>
                        {t.Transformer_ID}
                      </td>
                      <td className="py-2 px-3">{t.Age_Years} yrs</td>
                      <td className="py-2 px-3 font-mono text-amber-300">{t.Winding_Temperature_C}°C</td>
                      <td className="py-2 px-3 font-mono font-bold text-rose-400">{t.Dissolved_Gas_ppm} ppm</td>
                      <td className="py-2 px-3 font-mono">{t.Load_Percentage}%</td>
                      <td className="py-2 px-3 text-slate-400">{t.Cooling_Status}</td>
                      <td className="py-2 px-3 text-right space-x-1.5">
                        <button
                          onClick={() => onSelectTransformer(t)}
                          className="text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-0.5 rounded border border-slate-700 transition-colors font-medium"
                        >
                          Inspect
                        </button>
                        {currentRole !== 'VIEWER' && (
                          <button
                            onClick={() => onCreateWorkOrder(t)}
                            className="text-[11px] bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 px-2 py-0.5 rounded border border-rose-500/40 transition-colors font-medium"
                          >
                            Dispatch
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
};
