import React from 'react';
import { TransformerData } from '../types';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ScatterChart,
  Scatter,
  PieChart,
  Pie,
  Cell,
  CartesianGrid
} from 'recharts';
import { BarChart3, PieChart as PieIcon, Activity, Flame, Zap } from 'lucide-react';

interface AnalyticsChartsProps {
  transformers: TransformerData[];
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ transformers }) => {
  // 1. Health Status Distribution
  const healthyCount = transformers.filter(t => t.Health_Status === 'Healthy').length;
  const warningCount = transformers.filter(t => t.Health_Status === 'Warning').length;
  const criticalCount = transformers.filter(t => t.Health_Status === 'Critical').length;

  const healthData = [
    { name: 'Healthy', value: healthyCount, color: '#10b981' },
    { name: 'Warning', value: warningCount, color: '#f59e0b' },
    { name: 'Critical', value: criticalCount, color: '#f43f5e' },
  ];

  // 2. Cooling Status Distribution
  const coolingNormal = transformers.filter(t => t.Cooling_Status === 'Normal').length;
  const coolingFan = transformers.filter(t => t.Cooling_Status === 'Fan Running').length;
  const coolingPump = transformers.filter(t => t.Cooling_Status === 'Oil Pump Running').length;

  const coolingData = [
    { name: 'Normal (PASSIVE)', value: coolingNormal, color: '#38bdf8' },
    { name: 'Fan Running (FORCED AIR)', value: coolingFan, color: '#a855f7' },
    { name: 'Oil Pump (FORCED OIL)', value: coolingPump, color: '#ec4899' },
  ];

  // 3. Age vs DGA Scatter Plot
  const scatterAgeDga = transformers.map(t => ({
    x: t.Age_Years,
    y: t.Dissolved_Gas_ppm,
    id: t.Transformer_ID,
    status: t.Health_Status
  }));

  // 4. Load % vs Winding Temperature
  const scatterLoadTemp = transformers.map(t => ({
    x: t.Load_Percentage,
    y: t.Winding_Temperature_C,
    id: t.Transformer_ID,
    status: t.Health_Status
  }));

  return (
    <div id="analytics-charts-container" className="space-y-6">
      
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-cyan-400" />
            Substation Operational Analytics & Parameter Correlations
          </h2>
          <p className="text-xs text-slate-400">Statistical distribution of 500 high-voltage transformers across thermal, chemical, and physical parameters</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Health Status Distribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-slate-200 mb-4 flex items-center gap-2">
            <PieIcon className="h-4 w-4 text-emerald-400" />
            Fleet Health Category Breakdown
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={healthData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {healthData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Cooling Status Distribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-slate-200 mb-4 flex items-center gap-2">
            <Zap className="h-4 w-4 text-cyan-400" />
            Cooling Mode Operations Breakdown
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={coolingData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {coolingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Age vs Dissolved Gas (ppm) Scatter */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-slate-200 mb-4 flex items-center gap-2">
            <Activity className="h-4 w-4 text-amber-400" />
            Age (Years) vs. Dissolved Gas Concentration (ppm)
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" dataKey="x" name="Age (Years)" unit=" yrs" stroke="#94a3b8" fontSize={11} />
                <YAxis type="number" dataKey="y" name="DGA" unit=" ppm" stroke="#94a3b8" fontSize={11} />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Scatter name="Transformers" data={scatterAgeDga} fill="#f59e0b" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Load % vs Winding Temperature Correlation */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-slate-200 mb-4 flex items-center gap-2">
            <Flame className="h-4 w-4 text-rose-400" />
            Load Percentage (%) vs. Winding Temperature (°C)
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" dataKey="x" name="Load %" unit="%" stroke="#94a3b8" fontSize={11} />
                <YAxis type="number" dataKey="y" name="Winding Temp" unit="°C" stroke="#94a3b8" fontSize={11} />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Scatter name="Transformers" data={scatterLoadTemp} fill="#f43f5e" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};
