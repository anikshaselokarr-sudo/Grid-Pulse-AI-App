import React, { useState, useMemo } from 'react';
import { TransformerData, HealthStatus, CoolingStatus } from '../types';
import { calculateHealthScore } from '../utils/healthCalculations';
import { exportToCSV, parseCSVInput } from '../utils/exportUtils';
import { Search, Filter, Download, Upload, ArrowUpDown, ChevronLeft, ChevronRight, Eye, Wrench, Sparkles, CheckSquare, Square, FileSpreadsheet } from 'lucide-react';

interface AssetInventoryTableProps {
  transformers: TransformerData[];
  onSelectTransformer: (t: TransformerData) => void;
  onCreateWorkOrder: (t: TransformerData) => void;
  onImportNewDataset: (data: Partial<TransformerData>[]) => void;
  onOpenCopilot: (tId?: string) => void;
}

export const AssetInventoryTable: React.FC<AssetInventoryTableProps> = ({
  transformers,
  onSelectTransformer,
  onCreateWorkOrder,
  onImportNewDataset,
  onOpenCopilot,
}) => {
  // Search and Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [healthFilter, setHealthFilter] = useState<HealthStatus | 'All'>('All');
  const [coolingFilter, setCoolingFilter] = useState<CoolingStatus | 'All'>('All');
  const [minAge, setMinAge] = useState<number>(0);
  const [maxAge, setMaxAge] = useState<number>(30);
  const [minDGA, setMinDGA] = useState<number>(0);
  const [maxDGA, setMaxDGA] = useState<number>(600);

  // Sorting state
  const [sortField, setSortField] = useState<keyof TransformerData>('Transformer_ID');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  // Selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Handle Sort Toggle
  const handleSort = (field: keyof TransformerData) => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Filter & Sort Logic
  const filteredData = useMemo(() => {
    return transformers.filter(t => {
      // Search
      const matchesSearch = t.Transformer_ID.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Health Status
      const matchesHealth = healthFilter === 'All' || t.Health_Status === healthFilter;
      
      // Cooling Status
      const matchesCooling = coolingFilter === 'All' || t.Cooling_Status === coolingFilter;
      
      // Ranges
      const matchesAge = t.Age_Years >= minAge && t.Age_Years <= maxAge;
      const matchesDGA = t.Dissolved_Gas_ppm >= minDGA && t.Dissolved_Gas_ppm <= maxDGA;

      return matchesSearch && matchesHealth && matchesCooling && matchesAge && matchesDGA;
    }).sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortOrder === 'asc' ? valA - valB : valB - valA;
      }
      return 0;
    });
  }, [transformers, searchTerm, healthFilter, coolingFilter, minAge, maxAge, minDGA, maxDGA, sortField, sortOrder]);

  // Paginated Data
  const totalPages = Math.ceil(filteredData.length / pageSize) || 1;
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage, pageSize]);

  // Toggle Selection
  const toggleSelectAll = () => {
    if (selectedIds.size === paginatedData.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(paginatedData.map(t => t.Transformer_ID)));
    }
  };

  const toggleSelectOne = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  // File CSV Import Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const parsed = parseCSVInput(text);
        if (parsed.length > 0) {
          onImportNewDataset(parsed);
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div id="asset-inventory-container" className="space-y-3">
      
      {/* Search & Action Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-col lg:flex-row gap-3 justify-between items-center text-[12px]">
        
        {/* Left: Search input */}
        <div className="relative w-full lg:w-72">
          <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
          <input
            id="input-asset-search"
            type="text"
            placeholder="Filter ID (e.g. T0007)..."
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            className="w-full bg-slate-950 border border-slate-800 rounded-md pl-8 pr-3 py-1.5 text-[12px] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
          />
        </div>

        {/* Center: Quick Filter Selects */}
        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          {/* Health Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1 text-[11px]">
            <span className="text-slate-500 font-semibold uppercase">Health:</span>
            <select
              id="select-filter-health"
              value={healthFilter}
              onChange={(e) => { setHealthFilter(e.target.value as any); setCurrentPage(1); }}
              className="bg-transparent text-slate-200 focus:outline-none cursor-pointer font-medium"
            >
              <option value="All" className="bg-slate-900">All Statuses</option>
              <option value="Healthy" className="bg-slate-900 text-emerald-400">Healthy</option>
              <option value="Warning" className="bg-slate-900 text-amber-400">Warning</option>
              <option value="Critical" className="bg-slate-900 text-rose-400">Critical</option>
            </select>
          </div>

          {/* Cooling Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1 text-[11px]">
            <span className="text-slate-500 font-semibold uppercase">Cooling:</span>
            <select
              id="select-filter-cooling"
              value={coolingFilter}
              onChange={(e) => { setCoolingFilter(e.target.value as any); setCurrentPage(1); }}
              className="bg-transparent text-slate-200 focus:outline-none cursor-pointer font-medium"
            >
              <option value="All" className="bg-slate-900">All Cooling</option>
              <option value="Normal" className="bg-slate-900">Normal</option>
              <option value="Fan Running" className="bg-slate-900">Fan Running</option>
              <option value="Oil Pump Running" className="bg-slate-900">Oil Pump Running</option>
            </select>
          </div>
        </div>

        {/* Right: Export & Import CSV */}
        <div className="flex items-center space-x-2 w-full lg:w-auto justify-end">
          <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1.5 rounded-md text-[11px] font-semibold flex items-center gap-1.5 transition-colors">
            <Upload className="h-3.5 w-3.5 text-slate-400" />
            <span>Import CSV</span>
            <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
          </label>

          <button
            id="btn-export-csv"
            onClick={() => exportToCSV(filteredData)}
            className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-200 border border-indigo-500/30 px-2.5 py-1.5 rounded-md text-[11px] font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export ({filteredData.length})</span>
          </button>
        </div>

      </div>

      {/* Main Data Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[12px] text-slate-300">
            <thead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3 w-8 text-center">
                  <button onClick={toggleSelectAll} className="text-slate-400 hover:text-slate-200">
                    {selectedIds.size > 0 && selectedIds.size === paginatedData.length ? (
                      <CheckSquare className="h-3.5 w-3.5 text-indigo-400" />
                    ) : (
                      <Square className="h-3.5 w-3.5" />
                    )}
                  </button>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Transformer_ID')}>
                  <div className="flex items-center gap-1">
                    Asset ID <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Age_Years')}>
                  <div className="flex items-center gap-1">
                    Age <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Winding_Temperature_C')}>
                  <div className="flex items-center gap-1">
                    Winding Temp <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Oil_Temperature_C')}>
                  <div className="flex items-center gap-1">
                    Oil Temp <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Load_Percentage')}>
                  <div className="flex items-center gap-1">
                    Load % <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Dissolved_Gas_ppm')}>
                  <div className="flex items-center gap-1">
                    DGA (ppm) <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Vibration_mm_s')}>
                  <div className="flex items-center gap-1">
                    Vibr. <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Partial_Discharge_pC')}>
                  <div className="flex items-center gap-1">
                    PD (pC) <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3">Cooling</th>
                <th className="py-2.5 px-3 cursor-pointer hover:text-slate-100" onClick={() => handleSort('Health_Status')}>
                  <div className="flex items-center gap-1">
                    Health <ArrowUpDown className="h-3 w-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {paginatedData.map((t) => {
                const score = calculateHealthScore(t);
                const isSelected = selectedIds.has(t.Transformer_ID);

                let healthBadge = 'bg-emerald-500/20 text-emerald-300 border-emerald-800';
                if (t.Health_Status === 'Warning') healthBadge = 'bg-amber-500/20 text-amber-300 border-amber-800';
                if (t.Health_Status === 'Critical') healthBadge = 'bg-rose-500/20 text-rose-300 border-rose-800';

                return (
                  <tr
                    key={t.Transformer_ID}
                    className={`hover:bg-slate-800/40 transition-colors ${isSelected ? 'bg-indigo-950/40' : ''}`}
                  >
                    <td className="py-2 px-3 text-center">
                      <button onClick={() => toggleSelectOne(t.Transformer_ID)} className="text-slate-400 hover:text-slate-200">
                        {isSelected ? <CheckSquare className="h-3.5 w-3.5 text-indigo-400" /> : <Square className="h-3.5 w-3.5" />}
                      </button>
                    </td>
                    <td className="py-2 px-3 font-mono font-bold text-slate-100">{t.Transformer_ID}</td>
                    <td className="py-2 px-3">{t.Age_Years} yrs</td>
                    <td className="py-2 px-3 font-mono text-amber-300">{t.Winding_Temperature_C}°C</td>
                    <td className="py-2 px-3 font-mono">{t.Oil_Temperature_C}°C</td>
                    <td className="py-2 px-3 font-mono">{t.Load_Percentage}%</td>
                    <td className={`py-2 px-3 font-mono font-bold ${t.Dissolved_Gas_ppm > 400 ? 'text-rose-400' : t.Dissolved_Gas_ppm > 250 ? 'text-amber-400' : 'text-slate-300'}`}>
                      {t.Dissolved_Gas_ppm}
                    </td>
                    <td className="py-2 px-3 font-mono">{t.Vibration_mm_s}</td>
                    <td className="py-2 px-3 font-mono">{t.Partial_Discharge_pC}</td>
                    <td className="py-2 px-3 text-slate-400">{t.Cooling_Status}</td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded border ${healthBadge}`}>
                        {t.Health_Status} ({score})
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right space-x-1">
                      <button
                        onClick={() => onSelectTransformer(t)}
                        className="p-1 text-slate-400 hover:text-indigo-300 hover:bg-slate-800 rounded transition-colors"
                        title="View Detailed Telemetry & AI Diagnostic"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => onCreateWorkOrder(t)}
                        className="p-1 text-slate-400 hover:text-amber-300 hover:bg-slate-800 rounded transition-colors"
                        title="Create Work Order"
                      >
                        <Wrench className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => onOpenCopilot(t.Transformer_ID)}
                        className="p-1 text-slate-400 hover:text-purple-300 hover:bg-slate-800 rounded transition-colors"
                        title="Ask Gemini AI Copilot"
                      >
                        <Sparkles className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Footer & Pagination */}
        <div className="p-2.5 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-400">
          <div>
            Showing <strong className="text-slate-200">{(currentPage - 1) * pageSize + 1}</strong> to <strong className="text-slate-200">{Math.min(currentPage * pageSize, filteredData.length)}</strong> of <strong className="text-slate-200">{filteredData.length}</strong> items
          </div>

          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1.5">
              <span>Rows:</span>
              <select
                value={pageSize}
                onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                className="bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200 focus:outline-none"
              >
                <option value={15}>15</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>

            <div className="flex items-center space-x-1">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                className="p-1 rounded bg-slate-900 border border-slate-800 disabled:opacity-40 hover:bg-slate-800"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
              <span className="px-2 font-mono text-slate-200">{currentPage} / {totalPages}</span>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                className="p-1 rounded bg-slate-900 border border-slate-800 disabled:opacity-40 hover:bg-slate-800"
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
