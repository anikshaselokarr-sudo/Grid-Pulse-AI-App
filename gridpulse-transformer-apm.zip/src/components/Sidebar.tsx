import React from 'react';
import { LayoutDashboard, Table, Stethoscope, BarChart3, Wrench, Sliders, Database, Bot } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  criticalCount: number;
  openWorkOrdersCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  criticalCount,
  openWorkOrdersCount,
}) => {
  const analysisItems = [
    { id: 'dashboard', label: 'Executive Overview', icon: LayoutDashboard },
    { id: 'inventory', label: 'Asset Telemetry Data', icon: Table, badge: 500 },
    { id: 'diagnostics', label: 'DGA & IEEE Index', icon: Stethoscope, badge: criticalCount, badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-800' },
    { id: 'analytics', label: 'Analytics & Trends', icon: BarChart3 },
  ];

  const managementItems = [
    { id: 'workorders', label: 'Work Orders', icon: Wrench, badge: openWorkOrdersCount, badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-800' },
    { id: 'simulation', label: 'Grid Stress Sandbox', icon: Sliders },
    { id: 'schema', label: 'ERD & Database DDL', icon: Database },
  ];

  return (
    <aside id="sidebar-navigation" className="w-56 bg-slate-900 border-r border-slate-800 shrink-0 hidden lg:flex flex-col text-[12px]">
      
      {/* Navigation Groups */}
      <div className="flex-1 py-4 px-2 space-y-4 overflow-y-auto">
        
        {/* Analysis Section */}
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-500 px-3 mb-2 tracking-widest">
            Analysis
          </div>
          <nav className="space-y-1">
            {analysisItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-btn-${item.id}`}
                  onClick={() => onTabChange(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-md text-[12px] font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-600/10 text-indigo-400 rounded-md border border-indigo-500/20 shadow-sm'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Icon className={`h-4 w-4 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className={`px-1.5 py-0.2 text-[10px] font-bold rounded border ${item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Management Section */}
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-500 px-3 mb-2 tracking-widest">
            Management
          </div>
          <nav className="space-y-1">
            {managementItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-btn-${item.id}`}
                  onClick={() => onTabChange(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-md text-[12px] font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-600/10 text-indigo-400 rounded-md border border-indigo-500/20 shadow-sm'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Icon className={`h-4 w-4 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className={`px-1.5 py-0.2 text-[10px] font-bold rounded border ${item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

      </div>

      {/* Footer System Status Badge */}
      <div className="p-3 bg-slate-950/50 border-t border-slate-800 mt-auto">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-[11px] text-slate-400 font-medium">DB Sync: Stable</span>
        </div>
        <div className="text-[10px] text-slate-600 font-mono">IEEE C57.104 Engine v5.12</div>
      </div>

    </aside>
  );
};

