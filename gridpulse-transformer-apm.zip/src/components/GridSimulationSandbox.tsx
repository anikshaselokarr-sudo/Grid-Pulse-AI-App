import React, { useState } from 'react';
import { TransformerData, SimulationParams } from '../types';
import { Sliders, Flame, Sun, Wind, Play, RotateCcw, AlertTriangle, Activity } from 'lucide-react';

interface GridSimulationSandboxProps {
  transformers: TransformerData[];
  onApplySimulation: (params: SimulationParams) => void;
  onResetSimulation: () => void;
  isSimulated: boolean;
}

export const GridSimulationSandbox: React.FC<GridSimulationSandboxProps> = ({
  transformers,
  onApplySimulation,
  onResetSimulation,
  isSimulated,
}) => {
  const [ambientTempDelta, setAmbientTempDelta] = useState<number>(10);
  const [loadDelta, setLoadDelta] = useState<number>(25);
  const [coolingFailureRate, setCoolingFailureRate] = useState<number>(30);
  const [gasMultiplier, setGasMultiplier] = useState<number>(1.5);

  const handleRunSimulation = () => {
    onApplySimulation({
      ambientTempDelta,
      loadPercentageDelta: loadDelta,
      coolingSystemFailureRate: coolingFailureRate,
      acceleratedGasMultiplier: gasMultiplier,
    });
  };

  return (
    <div id="simulation-sandbox-container" className="space-y-6">
      
      {/* Simulation Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Sliders className="h-5 w-5 text-purple-400" />
            Grid Environmental & Load Stress Simulator
          </h2>
          <p className="text-xs text-slate-400">Simulate severe heatwaves, grid peak demand overloads, and cooling system outages across 500 units</p>
        </div>

        {isSimulated && (
          <button
            onClick={onResetSimulation}
            className="px-3 py-1.5 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-semibold flex items-center gap-1.5 hover:bg-rose-500/30 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Base Telemetry
          </button>
        )}
      </div>

      {/* Control Sliders Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Slider 1: Ambient Heatwave */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <label className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Sun className="h-4 w-4 text-amber-400" />
              Ambient Heatwave Spike (°C):
            </label>
            <span className="font-mono font-bold text-amber-400">+{ambientTempDelta} °C</span>
          </div>
          <input
            type="range"
            min={0}
            max={25}
            step={1}
            value={ambientTempDelta}
            onChange={(e) => setAmbientTempDelta(Number(e.target.value))}
            className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
          />
          <p className="text-[11px] text-slate-500">Increases base oil & winding hotspot thermal equilibrium across the grid</p>
        </div>

        {/* Slider 2: Peak Grid Load Shift */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <label className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Flame className="h-4 w-4 text-rose-400" />
              Peak Hour Grid Load Surge (%):
            </label>
            <span className="font-mono font-bold text-rose-400">+{loadDelta} %</span>
          </div>
          <input
            type="range"
            min={0}
            max={50}
            step={5}
            value={loadDelta}
            onChange={(e) => setLoadDelta(Number(e.target.value))}
            className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-rose-500"
          />
          <p className="text-[11px] text-slate-500">Simulates heavy industrial load spikes pushing transformers beyond rated kVA</p>
        </div>

        {/* Slider 3: Cooling Fan Failure Rate */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <label className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Wind className="h-4 w-4 text-cyan-400" />
              Cooling Fan Outage Rate (%):
            </label>
            <span className="font-mono font-bold text-cyan-400">{coolingFailureRate} % Outage</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={10}
            value={coolingFailureRate}
            onChange={(e) => setCoolingFailureRate(Number(e.target.value))}
            className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-cyan-500"
          />
          <p className="text-[11px] text-slate-500">Simulates forced air fans tripping, leading to rapid winding heat buildup</p>
        </div>

        {/* Slider 4: Accelerated DGA Gas Generation Rate */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <label className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Activity className="h-4 w-4 text-purple-400" />
              DGA Gas Generation Multiplier:
            </label>
            <span className="font-mono font-bold text-purple-400">{gasMultiplier}x Rate</span>
          </div>
          <input
            type="range"
            min={1.0}
            max={3.0}
            step={0.1}
            value={gasMultiplier}
            onChange={(e) => setGasMultiplier(Number(e.target.value))}
            className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-purple-500"
          />
          <p className="text-[11px] text-slate-500">Accelerates oil paper breakdown releasing dissolved hydrocarbon gases</p>
        </div>

      </div>

      {/* Action Submit */}
      <div className="flex justify-end">
        <button
          onClick={handleRunSimulation}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold px-6 py-3 rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-purple-900/40 transition-all"
        >
          <Play className="h-4 w-4 fill-white" />
          <span>Execute Monte-Carlo Stress Test</span>
        </button>
      </div>

    </div>
  );
};
