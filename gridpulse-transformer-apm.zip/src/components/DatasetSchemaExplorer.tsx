import React, { useState } from 'react';
import { Database, FileCode, Server, Layers, CheckCircle2, Copy, Check } from 'lucide-react';

export const DatasetSchemaExplorer: React.FC = () => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const sqlSchema = `-- ====================================================
-- PostgreSQL Database DDL Schema for Transformer APM System
-- ====================================================

CREATE TYPE health_status_enum AS ENUM ('Healthy', 'Warning', 'Critical');
CREATE TYPE cooling_status_enum AS ENUM ('Normal', 'Fan Running', 'Oil Pump Running');
CREATE TYPE user_role_enum AS ENUM ('SUPER_ADMIN', 'GRID_OPS_MANAGER', 'MAINTENANCE_ENGINEER', 'FIELD_TECHNICIAN', 'VIEWER');
CREATE TYPE priority_enum AS ENUM ('Low', 'Medium', 'High', 'Emergency');
CREATE TYPE work_order_status_enum AS ENUM ('Open', 'Scheduled', 'In Progress', 'Completed', 'Cancelled');

-- 1. Transformers Main Telemetry Table
CREATE TABLE transformers (
    transformer_id VARCHAR(10) PRIMARY KEY,
    age_years INT NOT NULL CHECK (age_years >= 0),
    oil_temperature_c NUMERIC(5, 2) NOT NULL,
    winding_temperature_c NUMERIC(5, 2) NOT NULL,
    ambient_temperature_c NUMERIC(5, 2) NOT NULL,
    voltage_kv NUMERIC(4, 1) DEFAULT 11.0,
    current_a NUMERIC(6, 2) NOT NULL,
    load_percentage INT NOT NULL CHECK (load_percentage BETWEEN 0 AND 120),
    oil_level_percentage NUMERIC(5, 2) NOT NULL,
    moisture_ppm NUMERIC(5, 2) NOT NULL,
    dissolved_gas_ppm NUMERIC(6, 2) NOT NULL,
    vibration_mm_s NUMERIC(4, 2) NOT NULL,
    partial_discharge_pc NUMERIC(5, 2) NOT NULL,
    cooling_status cooling_status_enum DEFAULT 'Normal',
    health_status health_status_enum NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for Query Acceleration
CREATE INDEX idx_transformers_health ON transformers(health_status);
CREATE INDEX idx_transformers_dga ON transformers(dissolved_gas_ppm DESC);
CREATE INDEX idx_transformers_winding_temp ON transformers(winding_temperature_c DESC);

-- 2. Maintenance Work Orders Table
CREATE TABLE work_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transformer_id VARCHAR(10) REFERENCES transformers(transformer_id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    priority priority_enum DEFAULT 'Medium',
    status work_order_status_enum DEFAULT 'Open',
    assigned_to VARCHAR(100),
    scheduled_date DATE,
    category VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
`;

  const prismaSchema = `// ====================================================
// Prisma Schema Definition for GridPulse APM
// ====================================================

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

enum HealthStatus {
  Healthy
  Warning
  Critical
}

enum CoolingStatus {
  Normal
  FanRunning
  OilPumpRunning
}

model Transformer {
  transformerId        String        @id @map("transformer_id") @db.VarChar(10)
  ageYears             Int           @map("age_years")
  oilTemperatureC      Float         @map("oil_temperature_c")
  windingTemperatureC  Float         @map("winding_temperature_c")
  ambientTemperatureC  Float         @map("ambient_temperature_c")
  voltageKv            Float         @default(11.0) @map("voltage_kv")
  currentA             Float         @map("current_a")
  loadPercentage       Int           @map("load_percentage")
  oilLevelPercentage   Float         @map("oil_level_percentage")
  moisturePpm          Float         @map("moisture_ppm")
  dissolvedGasPpm      Float         @map("dissolved_gas_ppm")
  vibrationMmS         Float         @map("vibration_mm_s")
  partialDischargePc   Float         @map("partial_discharge_pc")
  coolingStatus        CoolingStatus @default(Normal) @map("cooling_status")
  healthStatus         HealthStatus  @map("health_status")
  
  workOrders           WorkOrder[]
  
  createdAt            DateTime      @default(now()) @map("created_at")
  updatedAt            DateTime      @updatedAt @map("updated_at")

  @@map("transformers")
}

model WorkOrder {
  id            String      @id @default(uuid())
  transformerId String      @map("transformer_id")
  transformer   Transformer @relation(fields: [transformerId], references: [transformerId])
  title         String
  description   String?
  priority      String      @default("Medium")
  status        String      @default("Open")
  assignedTo    String?     @map("assigned_to")
  scheduledDate DateTime?   @map("scheduled_date")
  category      String?
  createdAt     DateTime    @default(now()) @map("created_at")

  @@map("work_orders")
}
`;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(label);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const fieldCatalog = [
    { name: 'Transformer_ID', type: 'VARCHAR(10)', pk: 'PRIMARY KEY', desc: 'Unique alphanumeric identifier for the 11kV substation transformer (T0001 to T0500).' },
    { name: 'Age_Years', type: 'INTEGER', pk: '-', desc: 'Operating age in service years (1 to 30 years).' },
    { name: 'Oil_Temperature_C', type: 'DECIMAL(5,2)', pk: '-', desc: 'Top oil temperature reading in °C.' },
    { name: 'Winding_Temperature_C', type: 'DECIMAL(5,2)', pk: '-', desc: 'Coil winding hotspot temperature reading in °C.' },
    { name: 'Ambient_Temperature_C', type: 'DECIMAL(5,2)', pk: '-', desc: 'Surrounding environmental ambient air temperature in °C.' },
    { name: 'Voltage_kV', type: 'DECIMAL(4,1)', pk: '-', desc: 'Nominal primary operating voltage (11.0 kV standard).' },
    { name: 'Current_A', type: 'DECIMAL(6,2)', pk: '-', desc: 'Primary phase current load in Amperes.' },
    { name: 'Load_Percentage', type: 'INTEGER', pk: '-', desc: 'Operating load relative to nameplate kVA rating (%).' },
    { name: 'Oil_Level_Percentage', type: 'DECIMAL(5,2)', pk: '-', desc: 'Insulating oil conservator tank fluid level (%).' },
    { name: 'Moisture_ppm', type: 'DECIMAL(5,2)', pk: '-', desc: 'Dielectric paper & oil moisture content in parts per million.' },
    { name: 'Dissolved_Gas_ppm', type: 'DECIMAL(6,2)', pk: '-', desc: 'Total Dissolved Gas Analysis (DGA) in oil (CH4, C2H4, C2H2, H2) in ppm.' },
    { name: 'Vibration_mm_s', type: 'DECIMAL(4,2)', pk: '-', desc: 'Mechanical core & tank vibration velocity RMS in mm/s.' },
    { name: 'Partial_Discharge_pC', type: 'DECIMAL(5,2)', pk: '-', desc: 'High frequency partial electrical discharge in picoCoulombs.' },
    { name: 'Cooling_Status', type: 'ENUM', pk: '-', desc: 'Active cooling mode: Normal (passive), Fan Running, Oil Pump Running.' },
    { name: 'Health_Status', type: 'ENUM', pk: '-', desc: 'Evaluated overall operational condition: Healthy, Warning, Critical.' },
  ];

  return (
    <div id="dataset-schema-container" className="space-y-6">
      
      {/* Overview Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2 mb-2">
          <Database className="h-5 w-5 text-cyan-400" />
          Step 1: Dataset Summary & Database Architecture
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          Comprehensive data dictionary, missing value audit (0 missing fields, 500 clean records), ERD relationships, PostgreSQL DDL script, and Prisma ORM definition.
        </p>
      </div>

      {/* Dataset Validation Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center space-x-3">
          <CheckCircle2 className="h-6 w-6 text-emerald-400" />
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase">Data Completeness</h4>
            <p className="text-sm font-mono text-emerald-400 font-bold">100% (500/500 Rows Valid)</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center space-x-3">
          <CheckCircle2 className="h-6 w-6 text-emerald-400" />
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase">Duplicates & Anomalies</h4>
            <p className="text-sm font-mono text-emerald-400 font-bold">0 Duplicates Found</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center space-x-3">
          <Layers className="h-6 w-6 text-cyan-400" />
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase">Primary Key</h4>
            <p className="text-sm font-mono text-cyan-300 font-bold">Transformer_ID (T0001..T0500)</p>
          </div>
        </div>
      </div>

      {/* Field Catalog Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-950 border-b border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Field Catalog & Data Types</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] font-semibold text-slate-400 uppercase bg-slate-950/60 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Field Name</th>
                <th className="py-2.5 px-3">Data Type</th>
                <th className="py-2.5 px-3">Key</th>
                <th className="py-2.5 px-3">Business & Engineering Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {fieldCatalog.map(f => (
                <tr key={f.name} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-mono font-bold text-cyan-300">{f.name}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-400">{f.type}</td>
                  <td className="py-2.5 px-3 font-mono text-amber-400">{f.pk}</td>
                  <td className="py-2.5 px-3 text-slate-300">{f.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Entity Relationship Diagram (ERD) Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <Server className="h-4 w-4 text-purple-400" />
          Entity Relationship Diagram (ERD) Visual Layout
        </h3>

        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col md:flex-row items-center justify-center gap-6 text-xs">
          {/* Entity 1: Transformers */}
          <div className="w-full md:w-64 bg-slate-900 border-2 border-cyan-500/40 rounded-xl p-3 space-y-1 shadow-lg">
            <div className="bg-cyan-500/20 text-cyan-300 font-bold px-2 py-1 rounded text-center">
              ENT_TRANSFORMERS
            </div>
            <div className="font-mono text-[11px] text-slate-300 space-y-1 pt-1">
              <div className="text-amber-400 font-bold">PK transformer_id</div>
              <div>age_years</div>
              <div>winding_temperature_c</div>
              <div>dissolved_gas_ppm</div>
              <div>health_status</div>
            </div>
          </div>

          <div className="text-slate-500 font-mono text-xs text-center">
            1 ------------ &lt; HAS MANY &gt; ------------ N
          </div>

          {/* Entity 2: Work Orders */}
          <div className="w-full md:w-64 bg-slate-900 border-2 border-amber-500/40 rounded-xl p-3 space-y-1 shadow-lg">
            <div className="bg-amber-500/20 text-amber-300 font-bold px-2 py-1 rounded text-center">
              ENT_WORK_ORDERS
            </div>
            <div className="font-mono text-[11px] text-slate-300 space-y-1 pt-1">
              <div className="text-amber-400 font-bold">PK id</div>
              <div className="text-cyan-400 font-bold">FK transformer_id</div>
              <div>title</div>
              <div>priority</div>
              <div>status</div>
            </div>
          </div>
        </div>
      </div>

      {/* DDL SQL & Prisma Tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* PostgreSQL SQL Schema */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold text-slate-200 uppercase flex items-center gap-1.5">
              <FileCode className="h-4 w-4 text-cyan-400" />
              PostgreSQL DDL Migration Script
            </h3>
            <button
              onClick={() => handleCopy(sqlSchema, 'sql')}
              className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded flex items-center gap-1"
            >
              {copiedCode === 'sql' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copiedCode === 'sql' ? 'Copied' : 'Copy SQL'}</span>
            </button>
          </div>
          <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-300 h-64 overflow-y-auto leading-relaxed">
            {sqlSchema}
          </pre>
        </div>

        {/* Prisma Schema */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold text-slate-200 uppercase flex items-center gap-1.5">
              <FileCode className="h-4 w-4 text-purple-400" />
              Prisma ORM Schema Definition
            </h3>
            <button
              onClick={() => handleCopy(prismaSchema, 'prisma')}
              className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded flex items-center gap-1"
            >
              {copiedCode === 'prisma' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copiedCode === 'prisma' ? 'Copied' : 'Copy Prisma'}</span>
            </button>
          </div>
          <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-300 h-64 overflow-y-auto leading-relaxed">
            {prismaSchema}
          </pre>
        </div>

      </div>

    </div>
  );
};
