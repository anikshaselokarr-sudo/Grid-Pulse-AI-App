import React from 'react';
import { UserRole } from '../types';
import { Activity, ShieldAlert, Cpu, Sparkles, SlidersHorizontal, UserCheck, Bell, Zap, Search } from 'lucide-react';

interface HeaderProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  activeTab: string;
  onOpenCopilot: () => void;
  criticalAlertCount: number;
  onOpenAlerts: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  activeTab,
  onOpenCopilot,
  criticalAlertCount,
  onOpenAlerts,
}) => {
  return (
    <header id="header-bar" className="h-12 border-b border-slate-800 bg-slate-900/80 backdrop-blur-md text-slate-200 sticky top-0 z-30 flex items-center px-4 sm:px-6 justify-between text-[13px]">
      
      {/* Left: Brand & High Density Breadcrumbs */}
      <div className="flex items-center space-x-3">
        <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center font-bold text-white text-[10px] shadow-sm">
          GP
        </div>
        <div className="flex items-center space-x-2 text-slate-400 font-medium text-[12px]">
          <span className="font-bold text-white uppercase tracking-tight text-xs">GridPulse APM</span>
          <span className="text-slate-700">/</span>
          <span className="text-slate-300 font-mono text-[11px] bg-slate-800/90 px-1.5 py-0.5 rounded border border-slate-700/60">Substation 11kV</span>
        </div>
      </div>

      {/* Center Section: AI Diagnostics & Telemetry Live Pill */}
      <div className="hidden md:flex items-center space-x-3">
        <button
          id="btn-copilot-quick"
          onClick={onOpenCopilot}
          className="flex items-center space-x-1.5 bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all shadow-sm group"
        >
          <Sparkles className="h-3.5 w-3.5 text-indigo-400 group-hover:rotate-12 transition-transform" />
          <span>AI Diagnostics Copilot</span>
        </button>

        <div className="flex items-center space-x-1.5 text-[11px] bg-slate-950/80 px-2.5 py-1 rounded-md border border-slate-800 text-slate-400">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-mono text-slate-300">500 Telemetry Feeds Active</span>
        </div>
      </div>

      {/* Right Controls: Alert Bell, Role Switcher & User Profile */}
      <div className="flex items-center space-x-3">
        
        {/* Critical Alert Bell */}
        <button
          id="btn-alert-bell"
          onClick={onOpenAlerts}
          className="relative p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-md transition-colors"
          title="View Critical Alerts"
        >
          <Bell className="h-4 w-4" />
          {criticalAlertCount > 0 && (
            <span className="absolute top-0.5 right-0.5 h-3.5 w-3.5 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {criticalAlertCount > 99 ? '99+' : criticalAlertCount}
            </span>
          )}
        </button>

        {/* Role Access Selector */}
        <div className="flex items-center space-x-1.5 bg-slate-800 border border-slate-700/80 rounded-md px-2 py-1 text-[11px]">
          <UserCheck className="h-3.5 w-3.5 text-indigo-400" />
          <select
            id="role-select"
            value={currentRole}
            onChange={(e) => onRoleChange(e.target.value as UserRole)}
            className="bg-transparent text-[11px] text-slate-200 font-semibold focus:outline-none cursor-pointer"
          >
            <option value="SUPER_ADMIN" className="bg-slate-900 text-slate-100">Super Admin</option>
            <option value="GRID_OPS_MANAGER" className="bg-slate-900 text-slate-100">Grid Ops Manager</option>
            <option value="MAINTENANCE_ENGINEER" className="bg-slate-900 text-slate-100">Maintenance Engineer</option>
            <option value="FIELD_TECHNICIAN" className="bg-slate-900 text-slate-100">Field Technician</option>
            <option value="VIEWER" className="bg-slate-900 text-slate-100">Viewer</option>
          </select>
        </div>

        {/* User Profile Badge */}
        <div className="hidden sm:flex items-center gap-2 border-l border-slate-800 pl-3">
          <div className="text-right leading-none">
            <div className="text-white font-bold text-[11px]">Ops Lead</div>
            <div className="text-[9px] text-slate-500 uppercase tracking-tight font-semibold">Grid Eng.</div>
          </div>
          <div className="w-7 h-7 rounded-full bg-indigo-600 border border-indigo-400/30 flex items-center justify-center font-bold text-white text-[10px] shadow-sm">
            GA
          </div>
        </div>

      </div>

    </header>
  );
};

