import React, { useState } from 'react';
import { TransformerData, UserRole, ChatMessage } from '../types';
import { Sparkles, Send, X, Bot, User, Loader2, Zap, CornerDownLeft } from 'lucide-react';

interface AICopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTransformerId?: string;
  transformers: TransformerData[];
  currentRole: UserRole;
}

export const AICopilotModal: React.FC<AICopilotModalProps> = ({
  isOpen,
  onClose,
  selectedTransformerId,
  transformers,
  currentRole,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'assistant',
      text: `Hello! I am GridPulse AI Copilot. I analyze Dissolved Gas Analysis (DGA), thermal hot-spots, and IEEE C57.104 compliance across all 500 substation transformers.\n\nHow can I assist your diagnostic or maintenance planning today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const quickPrompts = [
    `Analyze Transformer ${selectedTransformerId || 'T0007'} DGA risk`,
    `List top 5 transformers needing immediate oil degassing`,
    `Explain correlation between Winding Temp and Dissolved Gas`,
    `Suggest preventive maintenance schedule for Critical units`,
  ];

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || inputText;
    if (!query.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          selectedTransformerId,
          role: currentRole,
        }),
      });

      const data = await response.json();
      const botReply = data.reply || "Diagnostic analysis completed.";

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: botReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'assistant',
          text: "⚠️ Diagnostic API offline fallback: High Dissolved Gas (>400 ppm) combined with winding hotspot temperatures exceeding 90°C indicates thermal pyrolysis of mineral oil. Recommend immediate DGA degassing and load shedding.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="modal-ai-copilot" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl h-[85vh] flex flex-col overflow-hidden shadow-2xl relative">
        
        {/* Header */}
        <div className="bg-slate-950 p-4 border-b border-slate-800 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-500/20 rounded-xl border border-purple-500/30 text-purple-300">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                GridPulse AI Copilot
                {selectedTransformerId && (
                  <span className="text-xs font-mono font-normal text-cyan-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded">
                    Target: {selectedTransformerId}
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-400">Gemini 2.5 High-Voltage Substation Expert Assistant</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-100 rounded-lg">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Chat History */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`p-2 rounded-xl shrink-0 ${msg.sender === 'user' ? 'bg-cyan-600 text-slate-950' : 'bg-purple-600/30 text-purple-300 border border-purple-500/30'}`}>
                {msg.sender === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>

              <div className={`max-w-[80%] rounded-2xl p-3.5 leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-cyan-600 text-slate-950 font-medium rounded-tr-none'
                  : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none'
              }`}>
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <span className={`block text-[10px] mt-1.5 ${msg.sender === 'user' ? 'text-cyan-950 font-mono' : 'text-slate-500 font-mono'}`}>
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-purple-400 p-2 font-mono text-xs">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Analyzing DGA telemetry & IEEE standards...</span>
            </div>
          )}
        </div>

        {/* Quick Prompts */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex flex-wrap gap-1.5">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(qp)}
              className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg text-[11px] transition-colors"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask about DGA, hotspot temperatures, or maintenance advice..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !inputText.trim()}
            className="p-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-slate-950 font-bold rounded-xl transition-colors"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
